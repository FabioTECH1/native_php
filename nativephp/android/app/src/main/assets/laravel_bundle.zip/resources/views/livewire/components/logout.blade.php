<form wire:submit.prevent="logout">
    <button type="submit"
        class="p-2 text-gray-500 dark:text-gray-400 hover:text-red-500 dark:hover:text-red-400 transition-colors">
        <i class="fas fa-sign-out-alt"></i>
    </button>
</form>
