<div class="app-container flex flex-col">
    <!-- Header -->
    <header class="bg-white dark:bg-gray-800 shadow-sm px-6 py-4">
        <div class="flex justify-between items-center">
            <div class="flex items-center">
                <h1 class="font-bold text-gray-900 dark:text-white">Profile</h1>
            </div>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.logout');

$__html = app('livewire')->mount($__name, $__params, 'lw-62431062-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </header>

    <!-- Main Content -->
    <main class="content-area flex-1 px-6 py-4">
        <!-- User Profile Card -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6 mb-6">
            <div class="flex flex-col items-center mb-6">
                <!-- Profile Image - Shows base64 if available, falls back to initial -->
                <!--[if BLOCK]><![endif]--><?php if(auth()->user()->profile_image): ?>
                    <img src="<?php echo e(auth()->user()->profile_image); ?>"
                        class="w-20 h-20 rounded-full object-cover border-2 border-purple-200 dark:border-purple-800 mb-3"
                        alt="Profile photo">
                <?php else: ?>
                    <div
                        class="w-20 h-20 rounded-full gradient-bg flex items-center justify-center mb-3 text-white text-2xl">
                        <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <h2 class="text-xl font-bold text-gray-900 dark:text-white"><?php echo e(auth()->user()->name); ?></h2>
                <p class="text-gray-500 dark:text-gray-400 text-sm"><?php echo e(auth()->user()->email); ?></p>
            </div>

            <!-- User Details Table -->
            <div class="overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        <tr>
                            <td
                                class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-500 dark:text-gray-400">
                                Email Verified</td>
                            <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                <?php if(auth()->user()->email_verified_at): ?>
                                    <?php echo e(auth()->user()->email_verified_at->format('M d, Y H:i')); ?>

                                <?php else: ?>
                                    <span class="text-red-500 dark:text-red-400">Not verified</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                        </tr>
                        <tr>
                            <td
                                class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-500 dark:text-gray-400">
                                Created At</td>
                            <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                <?php echo e(auth()->user()->created_at->format('M d, Y H:i')); ?>

                            </td>
                        </tr>
                        <?php if(auth()->user()->profile_image_updated_at): ?>
                            <tr>
                                <td
                                    class="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-500 dark:text-gray-400">
                                    Profile Updated</td>
                                <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                                    <?php echo e(auth()->user()->profile_image_updated_at->format('M d, Y H:i')); ?>

                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <!-- Bottom Navigation -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.navigation');

$__html = app('livewire')->mount($__name, $__params, 'lw-62431062-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div>
<?php /**PATH /home/fabiotech/Documents/Mine/native_php/resources/views/livewire/profile.blade.php ENDPATH**/ ?>